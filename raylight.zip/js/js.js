var swiper = new Swiper('.swiper',{
   	speed:1200,
   	slidesPerView:'auto',
   	grabCursor:true,
   	spaceBetween:0,
   	loop:true,
   	parallax:true,
  	centeredSlides:true,
  	autoplay:{delay:3500,disableOnInteraction:false,},
});